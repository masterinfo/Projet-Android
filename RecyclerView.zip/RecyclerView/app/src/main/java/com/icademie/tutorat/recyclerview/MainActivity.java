package com.icademie.tutorat.recyclerview;

import androidx.appcompat.app.AlertDialog.Builder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PersonneViewHolder.ListeListener
{
    RecyclerView recyclerView = null;
    PersonneAdapter adapter = null;
    List<Personne> contenu = new ArrayList<Personne>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contenu.add(new Personne("Fillon", "François"));
        contenu.add(new Personne("Le Pen", "Marine"));
        contenu.add(new Personne("Macron", "Emmanuel"));
        contenu.add(new Personne("Mélenchon", "Jean-Luc"));
        recyclerView = (RecyclerView)findViewById(R.id.liste);
        adapter = new PersonneAdapter(contenu, this);
        //recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void afficher(Personne personne) {
        new Builder(this)
                .setTitle(getResources().getString(R.string.value_selected))
                .setMessage(personne.prenom + " " + personne.nom)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .create().show();
    }

    @Override
    public void modifier(Personne personne) {
        afficher(personne);
    }

    @Override
    public void supprimer(final Personne personne) {
        new Builder(this)
                .setTitle(getResources().getString(R.string.delete))
                .setMessage(String.format(getResources().getString(R.string.delete_confirm), personne.prenom, personne.nom))
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        contenu.remove(personne);
                        adapter.notifyDataSetChanged();
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .create().show();
    }
}
