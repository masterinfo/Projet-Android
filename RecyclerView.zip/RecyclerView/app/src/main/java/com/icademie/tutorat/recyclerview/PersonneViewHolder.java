package com.icademie.tutorat.recyclerview;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView.ViewHolder;

public class PersonneViewHolder extends ViewHolder {
    private final ListeListener listener;
    private TextView nom;
    private TextView prenom;

    public interface ListeListener {
        public void modifier(Personne personne);
        public void supprimer(Personne personne);
    }

    public PersonneViewHolder(final View itemView, final ListeListener listener) {
        super(itemView);
        this.listener = listener;
        nom = ((TextView) itemView.findViewById(R.id.nom));
        prenom = ((TextView) itemView.findViewById(R.id.prenom));
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.modifier((Personne) view.getTag());
            }
        });
        ((ImageView)itemView.findViewById(R.id.supprimer)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.supprimer((Personne) itemView.getTag());
            }
        });
    }

    public void display(Personne personne) {
        nom.setText(personne.nom);
        prenom.setText(personne.prenom);
    }
}
