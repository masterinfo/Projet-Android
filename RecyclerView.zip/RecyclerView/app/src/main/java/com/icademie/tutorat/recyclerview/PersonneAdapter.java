package com.icademie.tutorat.recyclerview;

import androidx.recyclerview.widget.RecyclerView.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class PersonneAdapter extends Adapter<PersonneViewHolder> {
    private PersonneViewHolder.ListeListener listener;
    private List<Personne> personnes = null;

    public PersonneAdapter(List<Personne> personnes, PersonneViewHolder.ListeListener listener) {
        this.personnes = personnes;
        this.listener = listener;
    }

    @Override
    public int getItemCount() {
        if (personnes != null)
            return personnes.size();
        else
            return 0;
    }

    @Override
    public PersonneViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.layout_liste, parent, false);
        return new PersonneViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(PersonneViewHolder holder, int position) {
        Personne personne = personnes.get(position);
        holder.display(personne);
        holder.itemView.setTag(personne);
    }
}
