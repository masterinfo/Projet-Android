package com.icademie.tutorat.recyclerview;

public class Personne {
    public String nom;
    public String prenom;

    public Personne(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    public String toString() {
        return nom + " " + prenom;
    }
}
